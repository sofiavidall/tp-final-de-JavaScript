let productosencarrito = localStorage.getItem("productos-en-carrito");
 productosencarrito = JSON.parse(productosencarrito);
const contenedorcarritovacio = document.querySelector("#carrito-vacio");
const contenedorcarritoproductos = document.querySelector("#carrito-productos");
const contenedorcarritoacciones = document.querySelector("#carrito-acciones");
const contenedorcarritocomprado = document.querySelector("#carrito-comprado");
let botoneseliminar = document.querySelectorAll(".carrito-producto-eliminr");
const botonvaciar = document.querySelector("#carrito-acciones-vaciar");


function cargarproductoscarrito(){


if (productosencarrito && productosencarrito.length > 0) {

   

    contenedorcarritovacio.classList.add("disabled");
    contenedorcarritoproductos.classList.remove("disabled");
    contenedorcarritoacciones.classList.remove("disabled");
    contenedorcarritocomprado.classList.add("disabled");

    contenedorcarritoproductos.innerHTML = "";


    productosencarrito.forEach(producto => {
       const div = document.createElement("div");
    div.classList.add("carrito-producto"); 
    div.innerHTML = `
    <img class="carrito-producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
                        <div class="carrito-producto-titulo">
                            <small>titulo</small>
                            <h3>${producto.titulo}</h3>
                        </div>
                        <div class="carrito-producto-cantidad">
                            <small>cantidad</small>
                            <p>${producto.cantidad}</p>
                        </div>
                        <div class="carrito-producto-precio">
                            <small>precio</small>
                            <p>$${producto.precio}</p>
                        </div>
                        <div class="carrito-producto-subtotal">
                            <small>subtotal</small>
                            <p>$${producto.precio * producto.cantidad}</p>
                        </div>
                        <button class="carrito-producto-eliminar" id="${producto.id}"><i class="bi bi-trash3"></i>eliminar</button>
    `;

    contenedorcarritoproductos.append(div);
    });
 
} else {
    contenedorcarritovacio.classList.remove("disabled");
    contenedorcarritoproductos.classList.add("disabled");
    contenedorcarritoacciones.classList.add("disabled");
    contenedorcarritocomprado.classList.add("disabled");
}
actualizarbotoneseliminar();
}

cargarproductoscarrito();

function actualizarbotoneseliminar() {
    botoneseliminar = document.querySelectorAll(".carrito-producto-eliminar");

    botoneseliminar.forEach(boton => {
        boton.addEventListener("click", eliminardelcarrito);
    });
}

function eliminardelcarrito(e) {
    const idboton = e.currentTarget.id;
    const index = productosencarrito.findIndex(producto => producto.id === idboton);
    productosencarrito.splice(index, 1);
    cargarproductoscarrito();

    localStorage.setItem("productos-en-carrito", JSON.stringify(productosencarrito));
       
}
botonvaciar.addEventListener("click", vaciarcarrito);
function vaciarcarrito() {

    productosencarrito.length = 0;
    localStorage.setItem("productos-en-carrito", JSON.stringify(productosencarrito));

}
