// PRODUCTOS
const productos = [
    // Abrigos
    {
        id: "abrigo-01",
        titulo: "Abrigo 01",
        imagen: "./img/01.jpg",
        categoria: {
            nombre: "Abrigos",
            id: "abrigos"
        },
        precio: 1000
    },
    {
        id: "abrigo-02",
        titulo: "Abrigo 02",
        imagen: "./img/02.jpg",
        categoria: {
            nombre: "Abrigos",
            id: "abrigos"
        },
        precio: 1000
    },
    {
        id: "abrigo-03",
        titulo: "Abrigo 03",
        imagen: "./img/03.jpg",
        categoria: {
            nombre: "Abrigos",
            id: "abrigos"
        },
        precio: 1000
    },
    {
        id: "abrigo-04",
        titulo: "Abrigo 04",
        imagen: "./img/04.jpg",
        categoria: {
            nombre: "Abrigos",
            id: "abrigos"
        },
        precio: 1000
    },
    {
        id: "abrigo-05",
        titulo: "Abrigo 05",
        imagen: "./img/05.jpg",
        categoria: {
            nombre: "Abrigos",
            id: "abrigos"
        },
        precio: 1000
    },
    // Camisetas
    {
        id: "camiseta-01",
        titulo: "Camiseta 01",
        imagen: "./img/01(1).jpg",
        categoria: {
            nombre: "Camisetas",
            id: "camisetas"
        },
        precio: 1000
    },
    {
        id: "camiseta-02",
        titulo: "Camiseta 02",
        imagen: "./img/022.jpg",
        categoria: {
            nombre: "Camisetas",
            id: "camisetas"
        },
        precio: 1000
    },
    {
        id: "camiseta-03",
        titulo: "Camiseta 03",
        imagen: "./img/033.jpg",
        categoria: {
            nombre: "Camisetas",
            id: "camisetas"
        },
        precio: 1000
    },
    {
        id: "camiseta-04",
        titulo: "Camiseta 04",
        imagen: "./img/044.jpg",
        categoria: {
            nombre: "Camisetas",
            id: "camisetas"
        },
        precio: 1000
    },
    {
        id: "camiseta-05",
        titulo: "Camiseta 05",
        imagen: "./img/055.jpg",
        categoria: {
            nombre: "Camisetas",
            id: "camisetas"
        },
        precio: 1000
    },
    {
        id: "camiseta-06",
        titulo: "Camiseta 06",
        imagen: "./img/06.jpg",
        categoria: {
            nombre: "Camisetas",
            id: "camisetas"
        },
        precio: 1000
    },
    {
        id: "camiseta-07",
        titulo: "Camiseta 07",
        imagen: "./img/07.jpg",
        categoria: {
            nombre: "Camisetas",
            id: "camisetas"
        },
        precio: 1000
    },
    {
        id: "camiseta-08",
        titulo: "Camiseta 08",
        imagen: "./img/08.jpg",
        categoria: {
            nombre: "Camisetas",
            id: "camisetas"
        },
        precio: 1000
    },
    // Pantalones
    {
        id: "pantalon-01",
        titulo: "Pantalón 01",
        imagen: "./img//01(2).jpg",
        categoria: {
            nombre: "Pantalones",
            id: "pantalones"
        },
        precio: 1000
    },
    {
        id: "pantalon-02",
        titulo: "Pantalón 02",
        imagen: "./img/0222.jpg",
        categoria: {
            nombre: "Pantalones",
            id: "pantalones"
        },
        precio: 1000
    },
    {
        id: "pantalon-03",
        titulo: "Pantalón 03",
        imagen: "./img/0333.jpg",
        categoria: {
            nombre: "Pantalones",
            id: "pantalones"
        },
        precio: 1000
    },
    {
        id: "pantalon-04",
        titulo: "Pantalón 04",
        imagen: "./img/0444.jpg",
        categoria: {
            nombre: "Pantalones",
            id: "pantalones"
        },
        precio: 1000
    },
    {
        id: "pantalon-05",
        titulo: "Pantalón 05",
        imagen: "./img/0555.jpg",
        categoria: {
            nombre: "Pantalones",
            id: "pantalones"
        },
        precio: 1000
    }
];

const contenedorproductos = document.querySelector("#contenedor-productos");
const botonescategorias = document.querySelectorAll(".boton-categoria");
const tituloprincipal = document.querySelector("#titulo-principal");
let botonesagregar = document.querySelectorAll(".producto-agregar");
const numerito = document.querySelector("#numerito");


 

function cargarproductos(productoselegidos){

    contenedorproductos.innerHTML = "";

    productoselegidos.forEach(producto => {
        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
        <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
          <div class="producto-detalles">
             <h3 class="producto-titulo">${producto.titulo}</h3>
             <p class="producto-precio">$${producto.precio}</p>
             <button class="producto-agregar" id="${producto.id}">AGREGAR</button>
         </div>
         `;

         contenedorproductos.append(div);  
    })
    actualizarbotonesagregar();
    
}

cargarproductos(productos);

botonescategorias.forEach(boton => {
    boton.addEventListener("click", (e) =>{

        botonescategorias.forEach(boton => boton.classList.remove("active"));
        e.currentTarget.classList.add("active");


        if(e.currentTarget.id != "todos") {
            const productocategoria = productos.find(producto => producto.categoria.id === e.currentTarget.id);
            tituloprincipal.innerText = productocategoria.categoria.nombre;
             const productosboton = productos.filter(producto => producto.categoria.id === e.currentTarget.id);

        cargarproductos(productosboton);
        } else{
            tituloprincipal.innerText = "Todos los productos";
            cargarproductos(productos);
        }
    })
});

function actualizarbotonesagregar(){
    botonesagregar = document.querySelectorAll(".producto-agregar");
    
    botonesagregar.forEach(boton => {
        boton.addEventListener("click", agregaralcarrito);
    });
}

let productosencarrito;

let productosencarritoLS = localStorage.getItem("productos-en-carrito");

if (productosencarritoLS){
    productosencarrito =  JSON.parse(productosencarritoLS);
    actualizarnumerito();
} else {
    productosencarrito = [];
}


function agregaralcarrito(e){

    const idboton = e.currentTarget.id;
    const productoagregado = productos.find(producto => producto.id === idboton);

    if(productosencarrito.some(producto => producto.id === idboton)){
      const index = productosencarrito.findIndex(producto => producto.id === idboton);
      productosencarrito[index].cantidad++;

    } else{
        productoagregado.cantidad = 1;
       productosencarrito.push(productoagregado);    
    } 
    
    actualizarnumerito();
    localStorage.setItem("productos-en-carrito", JSON.stringify(productosencarrito));

}

function actualizarnumerito(){
    let nuevonumerito = productosencarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    numerito.innerText = nuevonumerito;
}


