const openmenu = document.querySelector("#open-menu");
const closemenu = document.querySelector("#close-menu");
const aside = document.querySelector("aside");

openmenu.addEventListener("click", () => {
    aside.classList.add("aside-visible");
})

closemenu.addEventListener("click", () => {
    aside.classList.remove("aside-visible");
})
